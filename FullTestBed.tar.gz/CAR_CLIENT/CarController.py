from http.server import HTTPServer, BaseHTTPRequestHandler
from socketserver import ThreadingMixIn
import os

class Handler(BaseHTTPRequestHandler):
    def do_GET(self):
        found = True

        splittedPath = self.path.split('/')
        command = splittedPath[3]

        if len(splittedPath) > 4:
            param = splittedPath[4]

        if command == "accelerate":
            os.system("./Car_Accelerate.sh " + str(param))
        elif command == "stop":
            os.system("./Car_Stop.sh")
        else:
            self.send_response(404)
            found = False

        if found:        
            self.send_response(200)
        self.send_header("Content-Type", "text/html")
        self.end_headers()
        
class ThreadingSimpleServer(ThreadingMixIn, HTTPServer):
    pass

def run():
    server = ThreadingSimpleServer(('0.0.0.0', 81), Handler)
    server.serve_forever()

if __name__ == '__main__':
    run()
